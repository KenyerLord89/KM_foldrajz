﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace KM_Foldrajz_2022_12_01
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string connStr = "server = localhost; user = root; database = foldrajz; port = 3306";
            MySqlConnection conn = new MySqlConnection(connStr);

            conn.Open();

            string ElsoFeladat = "SELECT AVG(nepesseg) FROM `orszagok`;";
            MySqlCommand ElsoFeladatCMD = new MySqlCommand(ElsoFeladat, conn);
            MySqlDataReader ElsoFeladatRDR = ElsoFeladatCMD.ExecuteReader();
            while (ElsoFeladatRDR.Read())
            {
                ElsoFeladatRTB.AppendText(Convert.ToString(ElsoFeladatRDR[0]) + "\n");

            }
            ElsoFeladatRDR.Close();

            string MasodikFeladat = "SELECT AVG(terulet) FROM `orszagok`;";
            MySqlCommand MasodikFeladatCMD = new MySqlCommand(MasodikFeladat, conn);
            MySqlDataReader MasodikFeladatRDR = MasodikFeladatCMD.ExecuteReader();
            while (MasodikFeladatRDR.Read())
            {
                MasodikFeladatRTB.AppendText(Convert.ToString(MasodikFeladatRDR[0]) + "\n");
            }
            MasodikFeladatRDR.Close();

            string HarmadikFeladat = "SELECT ((SUM(nepesseg)*1000)/(SUM(terulet))) FROM `orszagok`;";
            MySqlCommand HarmadikFeladatCMD = new MySqlCommand(HarmadikFeladat, conn);
            MySqlDataReader HarmadikFeladatRDR = HarmadikFeladatCMD.ExecuteReader();
            while (HarmadikFeladatRDR.Read())
            {
                HarmadikFeladatRTB.AppendText(Convert.ToString(HarmadikFeladatRDR[0]) + "\n");
            }
            HarmadikFeladatRDR.Close();

            string NegyedikFeladat = "SELECT COUNT(`id`) FROM `orszagok` WHERE `terulet`<1000000;";
            MySqlCommand NegyedikFeladatCMD = new MySqlCommand(NegyedikFeladat, conn);
            MySqlDataReader NegyedikFeladatRDR = NegyedikFeladatCMD.ExecuteReader();
            while (NegyedikFeladatRDR.Read())
            {
                NegyedikFeladatRTB.AppendText(Convert.ToString(NegyedikFeladatRDR[0]) + "\n");
            }
            NegyedikFeladatRDR.Close();

            string OtodikFeladat = "SELECT COUNT(`id`) FROM `orszagok` WHERE `terulet`<100;";
            MySqlCommand OtodikFeladatCMD = new MySqlCommand(OtodikFeladat, conn);
            MySqlDataReader OtodikFeladatRDR = OtodikFeladatCMD.ExecuteReader();
            while (OtodikFeladatRDR.Read())
            {
                OtodikFeladatRTB.AppendText(Convert.ToString(OtodikFeladatRDR[0]) + "\n");
            }
            OtodikFeladatRDR.Close();

            string HatodikFeladat = "SELECT orszag FROM `orszagok` WHERE nepesseg<20;";
            MySqlCommand HatodikFeladatCMD = new MySqlCommand(HatodikFeladat, conn);
            MySqlDataReader HatodikFeladatRDR = HatodikFeladatCMD.ExecuteReader();
            while (HatodikFeladatRDR.Read())
            {
                HatodikFeladatRTB.AppendText(Convert.ToString(HatodikFeladatRDR[0]) + "\n");
            }
            HatodikFeladatRDR.Close();

            string HetedikFeladat = "SELECT COUNT(id) FROM `orszagok` WHERE terulet<100 OR nepesseg<20;";
            MySqlCommand HetedikFeladatCMD = new MySqlCommand(HetedikFeladat, conn);
            MySqlDataReader HetedikFeladatRDR = HetedikFeladatCMD.ExecuteReader();
            while (HetedikFeladatRDR.Read())
            {
                HetedikFeladatRTB.AppendText(Convert.ToString(HetedikFeladatRDR[0]) + "\n");
            }
            HetedikFeladatRDR.Close();

            string NyolcadikFeladat = "SELECT COUNT(`id`) FROM `orszagok` WHERE `terulet` BETWEEN 50 AND 150;";
            MySqlCommand NyolcadikFeladatCMD = new MySqlCommand(NyolcadikFeladat, conn);
            MySqlDataReader NyolcadikFeladatRDR = NyolcadikFeladatCMD.ExecuteReader();
            while (NyolcadikFeladatRDR.Read())
            {
                NyolcadikFeladatRTB.AppendText(Convert.ToString(NyolcadikFeladatRDR[0]) + "\n");
            }
            NyolcadikFeladatRDR.Close();

            string KilencedikFeladat = "SELECT COUNT(`id`) FROM `orszagok` WHERE `nepesseg` BETWEEN 8000 AND 12000;";
            MySqlCommand KilencedikFeladatCMD = new MySqlCommand(KilencedikFeladat, conn);
            MySqlDataReader KilencedikFeladatRDR = KilencedikFeladatCMD.ExecuteReader();
            while (KilencedikFeladatRDR.Read())
            {
                KilencedikFeladatRTB.AppendText(Convert.ToString(KilencedikFeladatRDR[0]) + "\n");
            }
            KilencedikFeladatRDR.Close();

            string TizedikFeladat = "SELECT COUNT(`id`) FROM `orszagok` WHERE nep_fovaros>20000;";
            MySqlCommand TizedikFeladatCMD = new MySqlCommand(TizedikFeladat, conn);
            MySqlDataReader TizedikFeladatRDR = TizedikFeladatCMD.ExecuteReader();
            while (TizedikFeladatRDR.Read())
            {
                TizedikFeladatRTB.AppendText(Convert.ToString(TizedikFeladatRDR[0]) + "\n");
            }
            TizedikFeladatRDR.Close();

            conn.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }
    }
}
