﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace KM_Foldrajz_2022_12_01
{
    /// <summary>
    /// Interaction logic for Window5.xaml
    /// </summary>
    public partial class Window5 : Window
    {
        public Window5()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string connStr = "server = localhost; user = root; database = foldrajz; port = 3306";
            MySqlConnection conn = new MySqlConnection(connStr);

            conn.Open();

            string ElsoFeladat = "SELECT `orszag`, ((`nepesseg`*1000)/`terulet`) FROM `orszagok` ORDER BY ((`nepesseg`*1000)/`terulet`) DESC LIMIT 1;";
            MySqlCommand ElsoFeladatCMD = new MySqlCommand(ElsoFeladat, conn);
            MySqlDataReader ElsoFeladatRDR = ElsoFeladatCMD.ExecuteReader();
            while (ElsoFeladatRDR.Read())
            {
                ElsoFeladatRTB.AppendText(Convert.ToString(ElsoFeladatRDR[0]) + " : " + Convert.ToString(ElsoFeladatRDR[1]) + "\n");

            }
            ElsoFeladatRDR.Close();

            string MasodikFeladat = "SELECT `orszag`, ((`nepesseg`*1000)/`terulet`) FROM `orszagok` ORDER BY ((`nepesseg`*1000)/`terulet`) ASC LIMIT 1;";
            MySqlCommand MasodikFeladatCMD = new MySqlCommand(MasodikFeladat, conn);
            MySqlDataReader MasodikFeladatRDR = MasodikFeladatCMD.ExecuteReader();
            while (MasodikFeladatRDR.Read())
            {
                MasodikFeladatRTB.AppendText(Convert.ToString(MasodikFeladatRDR[0]) + " : " + Convert.ToString(MasodikFeladatRDR[1]) + "\n");
            }
            MasodikFeladatRDR.Close();

            string HarmadikFeladat = "SELECT `orszag`, `terulet` FROM `orszagok` WHERE `foldr_hely` LIKE '%Afrika%' ORDER BY terulet DESC LIMIT 1;";
            MySqlCommand HarmadikFeladatCMD = new MySqlCommand(HarmadikFeladat, conn);
            MySqlDataReader HarmadikFeladatRDR = HarmadikFeladatCMD.ExecuteReader();
            while (HarmadikFeladatRDR.Read())
            {
                HarmadikFeladatRTB.AppendText(Convert.ToString(HarmadikFeladatRDR[0]) + " : " + Convert.ToString(HarmadikFeladatRDR[1]) + "\n");
            }
            HarmadikFeladatRDR.Close();

            string NegyedikFeladat = "SELECT `orszag`, (`nepesseg`*1000) FROM `orszagok` WHERE `foldr_hely` LIKE '%Amerika%' ORDER BY terulet ASC LIMIT 1;";
            MySqlCommand NegyedikFeladatCMD = new MySqlCommand(NegyedikFeladat, conn);
            MySqlDataReader NegyedikFeladatRDR = NegyedikFeladatCMD.ExecuteReader();
            while (NegyedikFeladatRDR.Read())
            {
                NegyedikFeladatRTB.AppendText(Convert.ToString(NegyedikFeladatRDR[0]) + " : " + Convert.ToString(NegyedikFeladatRDR[1]) + "\n");
            }
            NegyedikFeladatRDR.Close();

            string OtodikFeladat = "SELECT `orszag` FROM `orszagok` WHERE `foldr_hely` NOT LIKE '%városállam%' AND `foldr_hely` NOT LIKE '%törpeállam%' ORDER BY (`nepesseg`*1000)/`terulet` DESC LIMIT 3;";
            MySqlCommand OtodikFeladatCMD = new MySqlCommand(OtodikFeladat, conn);
            MySqlDataReader OtodikFeladatRDR = OtodikFeladatCMD.ExecuteReader();
            while (OtodikFeladatRDR.Read())
            {
                OtodikFeladatRTB.AppendText(Convert.ToString(OtodikFeladatRDR[0]) + "\n");
            }
            OtodikFeladatRDR.Close();

            string HatodikFeladat = "SELECT `fovaros` FROM `orszagok` ORDER BY `nep_fovaros` DESC LIMIT 6;";
            MySqlCommand HatodikFeladatCMD = new MySqlCommand(HatodikFeladat, conn);
            MySqlDataReader HatodikFeladatRDR = HatodikFeladatCMD.ExecuteReader();
            while (HatodikFeladatRDR.Read())
            {
                HatodikFeladatRTB.AppendText(Convert.ToString(HatodikFeladatRDR[0]) + "\n");
            }
            HatodikFeladatRDR.Close();

            string HetedikFeladat = "SELECT `orszag` FROM `orszagok` ORDER BY `gdp` DESC LIMIT 10;";
            MySqlCommand HetedikFeladatCMD = new MySqlCommand(HetedikFeladat, conn);
            MySqlDataReader HetedikFeladatRDR = HetedikFeladatCMD.ExecuteReader();
            while (HetedikFeladatRDR.Read())
            {
                HetedikFeladatRTB.AppendText(Convert.ToString(HetedikFeladatRDR[0]) + "\n");
            }
            HetedikFeladatRDR.Close();

            string NyolcadikFeladat = "SELECT `orszag` FROM `orszagok` ORDER BY `gdp`*`nepesseg`*1000 DESC LIMIT 10;";
            MySqlCommand NyolcadikFeladatCMD = new MySqlCommand(NyolcadikFeladat, conn);
            MySqlDataReader NyolcadikFeladatRDR = NyolcadikFeladatCMD.ExecuteReader();
            while (NyolcadikFeladatRDR.Read())
            {
                NyolcadikFeladatRTB.AppendText(Convert.ToString(NyolcadikFeladatRDR[0]) + "\n");
            }
            NyolcadikFeladatRDR.Close();

            string KilencedikFeladat = "SELECT `orszag` FROM `orszagok` ORDER BY `gdp`*`nepesseg`*1000 ASC LIMIT 1;";
            MySqlCommand KilencedikFeladatCMD = new MySqlCommand(KilencedikFeladat, conn);
            MySqlDataReader KilencedikFeladatRDR = KilencedikFeladatCMD.ExecuteReader();
            while (KilencedikFeladatRDR.Read())
            {
                KilencedikFeladatRTB.AppendText(Convert.ToString(KilencedikFeladatRDR[0]) + "\n");
            }
            KilencedikFeladatRDR.Close();

            string TizedikFeladat = "SELECT `orszag` FROM `orszagok` ORDER BY `terulet` LIMIT 1 OFFSET 39;";
            MySqlCommand TizedikFeladatCMD = new MySqlCommand(TizedikFeladat, conn);
            MySqlDataReader TizedikFeladatRDR = TizedikFeladatCMD.ExecuteReader();
            while (TizedikFeladatRDR.Read())
            {
                TizedikFeladatRTB.AppendText(Convert.ToString(TizedikFeladatRDR[0]) + "\n");
            }
            TizedikFeladatRDR.Close();

            conn.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }
    }
}
