﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace KM_Foldrajz_2022_12_01
{
    /// <summary>
    /// Interaction logic for Window6.xaml
    /// </summary>
    public partial class Window6 : Window
    {
        public Window6()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string connStr = "server = localhost; user = root; database = foldrajz; port = 3306";
            MySqlConnection conn = new MySqlConnection(connStr);

            conn.Open();

            string ElsoFeladat = "SELECT `orszag` FROM `orszagok` ORDER BY (`nepesseg`*1000)/`terulet` LIMIT 1 OFFSET 14;";
            MySqlCommand ElsoFeladatCMD = new MySqlCommand(ElsoFeladat, conn);
            MySqlDataReader ElsoFeladatRDR = ElsoFeladatCMD.ExecuteReader();
            while (ElsoFeladatRDR.Read())
            {
                ElsoFeladatRTB.AppendText(Convert.ToString(ElsoFeladatRDR[0]) + "\n");

            }
            ElsoFeladatRDR.Close();

            string MasodikFeladat = "SELECT `orszag` FROM `orszagok` ORDER BY (`nepesseg`*1000)/`terulet` DESC LIMIT 1 OFFSET 60;";
            MySqlCommand MasodikFeladatCMD = new MySqlCommand(MasodikFeladat, conn);
            MySqlDataReader MasodikFeladatRDR = MasodikFeladatCMD.ExecuteReader();
            while (MasodikFeladatRDR.Read())
            {
                MasodikFeladatRTB.AppendText(Convert.ToString(MasodikFeladatRDR[0]) + "\n");
            }
            MasodikFeladatRDR.Close();

            string HarmadikFeladat = "SELECT `orszag` FROM `orszagok` ORDER BY ABS((SELECT `terulet` FROM orszagok WHERE `orszag` LIKE 'Magyarország')-terulet) LIMIT 3 OFFSET 1;";
            MySqlCommand HarmadikFeladatCMD = new MySqlCommand(HarmadikFeladat, conn);
            MySqlDataReader HarmadikFeladatRDR = HarmadikFeladatCMD.ExecuteReader();
            while (HarmadikFeladatRDR.Read())
            {
                HarmadikFeladatRTB.AppendText(Convert.ToString(HarmadikFeladatRDR[0]) + "\n");
            }
            HarmadikFeladatRDR.Close();

            string NegyedikFeladat = "SELECT ((SELECT SUM(`nepesseg`) FROM `orszagok` WHERE `foldr_hely` LIKE '%Ázsia%'))/(SUM(`nepesseg`)) FROM `orszagok`;";
            MySqlCommand NegyedikFeladatCMD = new MySqlCommand(NegyedikFeladat, conn);
            MySqlDataReader NegyedikFeladatRDR = NegyedikFeladatCMD.ExecuteReader();
            while (NegyedikFeladatRDR.Read())
            {
                NegyedikFeladatRTB.AppendText(Convert.ToString(NegyedikFeladatRDR[0]) + "\n");
            }
            NegyedikFeladatRDR.Close();

            string OtodikFeladat = "SELECT ((SELECT `terulet` FROM `orszagok` WHERE `orszag` LIKE 'Oroszország'))/(SUM(`terulet`)) FROM `orszagok`;";
            MySqlCommand OtodikFeladatCMD = new MySqlCommand(OtodikFeladat, conn);
            MySqlDataReader OtodikFeladatRDR = OtodikFeladatCMD.ExecuteReader();
            while (OtodikFeladatRDR.Read())
            {
                OtodikFeladatRTB.AppendText(Convert.ToString(OtodikFeladatRDR[0]) + "\n");
            }
            OtodikFeladatRDR.Close();

            string HatodikFeladat = "SELECT ((SELECT SUM(`nepesseg`) FROM orszagok WHERE `penznem` LIKE 'euró')/SUM(`nepesseg`))*100 FROM `orszagok`;";
            MySqlCommand HatodikFeladatCMD = new MySqlCommand(HatodikFeladat, conn);
            MySqlDataReader HatodikFeladatRDR = HatodikFeladatCMD.ExecuteReader();
            while (HatodikFeladatRDR.Read())
            {
                HatodikFeladatRTB.AppendText(Convert.ToString(HatodikFeladatRDR[0]) + "\n");
            }
            HatodikFeladatRDR.Close();

            string HetedikFeladat = "SELECT (MAX(`gdp`))/(MIN(`gdp`)) FROM `orszagok` WHERE `gdp` <> 0;";
            MySqlCommand HetedikFeladatCMD = new MySqlCommand(HetedikFeladat, conn);
            MySqlDataReader HetedikFeladatRDR = HetedikFeladatCMD.ExecuteReader();
            while (HetedikFeladatRDR.Read())
            {
                HetedikFeladatRTB.AppendText(Convert.ToString(HetedikFeladatRDR[0]) + "\n");
            }
            HetedikFeladatRDR.Close();

            string NyolcadikFeladat = "SELECT ((SELECT SUM(`gdp`) FROM `orszagok` WHERE `orszag` LIKE 'Amerikai Egyesült Államok')/(SUM(`gdp`)))*100 FROM `orszagok`;";
            MySqlCommand NyolcadikFeladatCMD = new MySqlCommand(NyolcadikFeladat, conn);
            MySqlDataReader NyolcadikFeladatRDR = NyolcadikFeladatCMD.ExecuteReader();
            while (NyolcadikFeladatRDR.Read())
            {
                NyolcadikFeladatRTB.AppendText(Convert.ToString(NyolcadikFeladatRDR[0]) + "\n");
            }
            NyolcadikFeladatRDR.Close();

            string KilencedikFeladat = "SELECT ((SELECT SUM(`gdp`) FROM `orszagok` WHERE `penznem` LIKE 'euro')/(SUM(`gdp`)))*100 FROM `orszagok`;";
            MySqlCommand KilencedikFeladatCMD = new MySqlCommand(KilencedikFeladat, conn);
            MySqlDataReader KilencedikFeladatRDR = KilencedikFeladatCMD.ExecuteReader();
            while (KilencedikFeladatRDR.Read())
            {
                KilencedikFeladatRTB.AppendText(Convert.ToString(KilencedikFeladatRDR[0]) + "\n");
            }
            KilencedikFeladatRDR.Close();

            /*string TizedikFeladat = "";
            MySqlCommand TizedikFeladatCMD = new MySqlCommand(TizedikFeladat, conn);
            MySqlDataReader TizedikFeladatRDR = TizedikFeladatCMD.ExecuteReader();
            while (TizedikFeladatRDR.Read())
            {
                TizedikFeladatRTB.AppendText(Convert.ToString(TizedikFeladatRDR[0]) + "\n");
            }
            TizedikFeladatRDR.Close();*/

            conn.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }
    }
}
