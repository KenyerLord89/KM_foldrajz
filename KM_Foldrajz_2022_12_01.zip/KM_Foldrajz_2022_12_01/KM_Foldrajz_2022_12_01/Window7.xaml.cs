﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace KM_Foldrajz_2022_12_01
{
    /// <summary>
    /// Interaction logic for Window7.xaml
    /// </summary>
    public partial class Window7 : Window
    {
        public Window7()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string connStr = "server = localhost; user = root; database = foldrajz; port = 3306";
            MySqlConnection conn = new MySqlConnection(connStr);

            conn.Open();

            string ElsoFeladat = "SELECT `allamforma` FROM `orszagok` WHERE `foldr_hely` LIKE '%Európa%' GROUP BY `allamforma`; ";
            MySqlCommand ElsoFeladatCMD = new MySqlCommand(ElsoFeladat, conn);
            MySqlDataReader ElsoFeladatRDR = ElsoFeladatCMD.ExecuteReader();
            while (ElsoFeladatRDR.Read())
            {
                ElsoFeladatRTB.AppendText(Convert.ToString(ElsoFeladatRDR[0]) + "\n");

            }
            ElsoFeladatRDR.Close();

            string MasodikFeladat = "SELECT COUNT(DISTINCT `allamforma`) FROM `orszagok`;";
            MySqlCommand MasodikFeladatCMD = new MySqlCommand(MasodikFeladat, conn);
            MySqlDataReader MasodikFeladatRDR = MasodikFeladatCMD.ExecuteReader();
            while (MasodikFeladatRDR.Read())
            {
                MasodikFeladatRTB.AppendText(Convert.ToString(MasodikFeladatRDR[0]) + "\n");
            }
            MasodikFeladatRDR.Close();

            string HarmadikFeladat = "SELECT COUNT(DISTINCT `penznem`) FROM `orszagok` WHERE `penznem` NOT LIKE 'euro';";
            MySqlCommand HarmadikFeladatCMD = new MySqlCommand(HarmadikFeladat, conn);
            MySqlDataReader HarmadikFeladatRDR = HarmadikFeladatCMD.ExecuteReader();
            while (HarmadikFeladatRDR.Read())
            {
                HarmadikFeladatRTB.AppendText(Convert.ToString(HarmadikFeladatRDR[0]) + "\n");
            }
            HarmadikFeladatRDR.Close();

            string NegyedikFeladat = "SELECT `penznem` FROM `orszagok` ORDER BY COUNT(`penznem`);";
            MySqlCommand NegyedikFeladatCMD = new MySqlCommand(NegyedikFeladat, conn);
            MySqlDataReader NegyedikFeladatRDR = NegyedikFeladatCMD.ExecuteReader();
            while (NegyedikFeladatRDR.Read())
            {
                NegyedikFeladatRTB.AppendText(Convert.ToString(NegyedikFeladatRDR[0]) + "\n");
            }
            NegyedikFeladatRDR.Close();

            string OtodikFeladat = "SELECT `orszag` FROM `orszagok` GROUP BY `allamforma` HAVING COUNT(`allamforma`) = 1;";
            MySqlCommand OtodikFeladatCMD = new MySqlCommand(OtodikFeladat, conn);
            MySqlDataReader OtodikFeladatRDR = OtodikFeladatCMD.ExecuteReader();
            while (OtodikFeladatRDR.Read())
            {
                OtodikFeladatRTB.AppendText(Convert.ToString(OtodikFeladatRDR[0]) + "\n");
            }
            OtodikFeladatRDR.Close();

            conn.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }
    }
}
